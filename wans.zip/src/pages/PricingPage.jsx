import React from 'react';
import Packages from '@/components/Packages';

const PricingPage = () => {
    return (
        <div className="pt-16 lowercase">
            <Packages />
        </div>
    );
};

export default PricingPage;